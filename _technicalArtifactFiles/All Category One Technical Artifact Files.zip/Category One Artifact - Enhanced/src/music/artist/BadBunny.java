package music.artist;

import java.util.ArrayList;

import snhu.jukebox.playlist.Song;

public class BadBunny {

	ArrayList<Song> albumTracks;
    private final String artistName = "Bad Bunny";
    String albumTitle;
    
    public BadBunny() {
    }
    
    public ArrayList<Song> getBadBunnySongs() {
    	
    	 albumTracks = new ArrayList<Song>();                           //Instantiate the album so we can populate it below
    	 Song track1 = new Song("El Apagon", artistName);        		//Create a song     
         this.albumTracks.add(track1);                                  //Add the first song to song list
         return albumTracks;                                            //Return the songs for Adele in the form of an ArrayList
    }
}