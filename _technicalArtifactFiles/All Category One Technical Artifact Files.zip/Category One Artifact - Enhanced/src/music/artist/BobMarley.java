package music.artist;

import java.util.ArrayList;

import snhu.jukebox.playlist.Song;

public class BobMarley {

	ArrayList<Song> albumTracks;
    private final String artistName = "Bob Marley";
    String albumTitle;
    
    public BobMarley() {
    }
    
    public ArrayList<Song> getBobMarleySongs() {
    	
    	 albumTracks = new ArrayList<Song>();                           //Instantiate the album so we can populate it below
    	 Song track1 = new Song("Could You Be Loved", artistName);        		//Create a song     
         this.albumTracks.add(track1);                                  //Add the first song to song list
         return albumTracks;                                            //Return the songs for Adele in the form of an ArrayList
    }
}