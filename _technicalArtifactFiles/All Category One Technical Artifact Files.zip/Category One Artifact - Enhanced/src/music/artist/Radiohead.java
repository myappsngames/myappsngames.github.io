package music.artist;

import java.util.ArrayList;

import snhu.jukebox.playlist.Song;

public class Radiohead {

	ArrayList<Song> albumTracks;
    private final String artistName = "Radiohead";
    String albumTitle;
    
    public Radiohead() {
    }
    
    public ArrayList<Song> getRadioheadSongs() {
    	
    	 albumTracks = new ArrayList<Song>();                           //Instantiate the album so we can populate it below
    	 Song track1 = new Song("Jigsaw Falling into Place", artistName);        		//Create a song     
         this.albumTracks.add(track1);                                  //Add the first song to song list
         return albumTracks;                                            //Return the songs for Adele in the form of an ArrayList
    }
}