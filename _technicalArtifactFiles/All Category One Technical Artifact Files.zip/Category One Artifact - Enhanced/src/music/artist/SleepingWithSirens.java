package music.artist;

import snhu.jukebox.playlist.Song;
import java.util.ArrayList;

public class SleepingWithSirens {
	
	ArrayList<Song> albumTracks;
    String albumTitle;
    
    public SleepingWithSirens() {
    }
    
    public ArrayList<Song> getSleepingWithSirensSongs() {
    	
    	 albumTracks = new ArrayList<Song>();                                   //Instantiate the album so we can populate it below
    	 Song track1 = new Song("Who Are You Now", "SleepingWithSirens");  		//Create a song
         Song track2 = new Song("If You Can't Hang", "SleepingWithSirens");     //Create another song
         this.albumTracks.add(track1);                                          //Add the first song to song list
         this.albumTracks.add(track2);                                          //Add the second song to song list
         return albumTracks;                                                    //Return the songs for the Beatles in the form of an ArrayList
    }
}
