package music.artist;

import snhu.jukebox.playlist.Song;
import java.util.ArrayList;

public class StrayKids {
	
	ArrayList<Song> albumTracks;
    String albumTitle;
    
    public StrayKids() {
    }
    
    public ArrayList<Song> getStrayKidsSongs() {
    	
    	 albumTracks = new ArrayList<Song>();                                   //Instantiate the album so we can populate it below
    	 Song track1 = new Song("Chk Chk Boom", "Stray Kids");                  //Create a song
         Song track2 = new Song("MEGAVERSE", "Stray Kids");                     //Create another song
         Song track3 = new Song("MANIAC", "Stray Kids");						//Third Song
         Song track4 = new Song("LALALALA", "Stray Kids");						//Fourth Song
         Song track5 = new Song("God's Menu", "Stray Kids");					//Fifth Song
         this.albumTracks.add(track1);                                          //Add the first song to song list for the Stray Kids
         this.albumTracks.add(track2);                                          //Add the second song to song list for the Stray Kids
         this.albumTracks.add(track3);											//Add the third song to song list for the Stray Kids
         this.albumTracks.add(track4);											//Add the fourth song to song list for the Stray Kids
         this.albumTracks.add(track5);											//Add the fifth song to song list for the Stray Kids
         return albumTracks;                                                    //Return the songs for the Stray Kids in the form of an ArrayList
    }
}
