package snhu.jukebox.playlist.tests;

import static org.junit.Assert.*;
import java.util.ArrayList;
import org.junit.Test;
import music.artist.*;
import snhu.jukebox.playlist.Song;

public class DominickMarquezTest {
	
	// Artist Album Size Tests
	
	// Sleeping With Sirens Band
	@Test
	public void testGetSleepingWithSirensAlbumSize() throws NoSuchFieldException, SecurityException {
		 SleepingWithSirens SleepingWithSirensBand = new SleepingWithSirens();
		 ArrayList<Song> sleepingWithSirensTracks = new ArrayList<Song>();
		 sleepingWithSirensTracks = SleepingWithSirensBand.getSleepingWithSirensSongs();
		 assertEquals(2, sleepingWithSirensTracks.size());
	}
	
	// Metallica Band
	@Test
	public void testMetallicaAlbumSize() throws NoSuchFieldException, SecurityException {
		 Metallica MetallicaBand = new Metallica();
		 ArrayList<Song> metallicaTracks = new ArrayList<Song>();
		 metallicaTracks = MetallicaBand.getMetallicaSongs();
		 assertEquals(3, metallicaTracks.size());
	}
	
	// Stray Kids Band
	@Test
	public void StrayKidsAlbumSize() throws NoSuchFieldException, SecurityException {
		 StrayKids StrayKidsBand = new StrayKids();
		 ArrayList<Song> strayKidsTracks = new ArrayList<Song>();
		 strayKidsTracks = StrayKidsBand.getStrayKidsSongs();
		 assertEquals(5, strayKidsTracks.size());
	}
}
