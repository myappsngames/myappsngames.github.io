package snhu.student.playlists;

import snhu.jukebox.playlist.PlayableSong;
import music.artist.*;
import java.util.LinkedList;

public class AngelMoreira_Playlist {
    
	public LinkedList<PlayableSong> StudentPlaylist(){
	
	LinkedList<PlayableSong> playlist = new LinkedList<PlayableSong>();
	
    // Array of artist instances in order
    Object[] artists = {
        new Radiohead(),
        new BobMarley(),
        new ElGranCombo(),
        new MarcAnthony(),
        new BadBunny()
    };
	
    // Iterate over the artist array and add songs to the playlist
    for (Object artist : artists) {
    	if (artist instanceof Radiohead) {
            Radiohead radiohead = (Radiohead) artist;
            playlist.addAll(radiohead.getRadioheadSongs());
        } else if (artist instanceof BobMarley) {
            BobMarley bobMarley = (BobMarley) artist;
            playlist.addAll(bobMarley.getBobMarleySongs());
        } else if (artist instanceof ElGranCombo) {
            ElGranCombo elGranCombo = (ElGranCombo) artist;
            playlist.addAll(elGranCombo.getElGranComboSongs());
        } else if (artist instanceof MarcAnthony) {
            MarcAnthony marcAnthony = (MarcAnthony) artist;
            playlist.addAll(marcAnthony.getMarcAnthonySongs());
        } else if (artist instanceof BadBunny) {
            BadBunny badBunny = (BadBunny) artist;
            playlist.addAll(badBunny.getBadBunnySongs());
        }
    }
	
    return playlist;
	}
}
