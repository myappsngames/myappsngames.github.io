package snhu.student.playlists;

import snhu.jukebox.playlist.PlayableSong;
import snhu.jukebox.playlist.Song;
import music.artist.*; // Import artist-specific classes
import java.util.LinkedList;
import java.util.List;

/**
 * The DominickMarquez_Playlist class is responsible for creating a playlist
 * for the DominickMarquez class. It is a singleton class, so there is only
 */
public class DominickMarquez_Playlist {

	/**
     * Creates a student playlist containing songs from different bands.
     *
     * @return A LinkedList of PlayableSong objects representing the playlist.
     */
	public LinkedList<PlayableSong> studentPlaylist() {

    	LinkedList<PlayableSong> playlist = new LinkedList<>(); // Initialize the playlist

    	try {
			// Add songs from Metallica
            addSongsFromBand(playlist, new Metallica().getMetallicaSongs(), 2);

			// Add songs from Sleeping With Sirens
            addSongsFromBand(playlist, new SleepingWithSirens().getSleepingWithSirensSongs(), 2);

			// Add songs from Stray Kids
            addSongsFromBand(playlist, new StrayKids().getStrayKidsSongs(), 1);
        } catch (Exception e) {
            System.err.println("Error creating playlist: " + e.getMessage()); // Print error to standard error stream
        }

    	return playlist; // Return the created playlist
	}

	/**+
     * Adds a specified number of songs from a given list to the playlist.
     * Handles null or empty song lists and prevents IndexOutOfBoundsExceptions.
     *
     * @param playlist       The playlist to add songs to.
     * @param songs          The list of songs to add from.
     * @param numSongsToAdd  The maximum number of songs to add.
     */
	private void addSongsFromBand(LinkedList<PlayableSong> playlist, List<Song> songs, int numSongsToAdd) {
    	if (songs == null) {
            System.err.println("Warning: Band returned a null song list.");
            return; // Exit early to avoid NullPointerException
        }
        if (songs.isEmpty()) {
            System.err.println("Warning: Band returned an empty song list.");
            return; // Exit early as there are no songs to add+
        }

		// Iterate through the songs, adding up to numSongsToAdd or the available number of songs
        for (int i = 0; i < Math.min(numSongsToAdd, songs.size()); i++) {
            playlist.add(songs.get(i));
        }
	}
}
