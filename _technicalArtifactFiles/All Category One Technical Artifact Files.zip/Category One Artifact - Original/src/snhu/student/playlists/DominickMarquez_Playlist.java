package snhu.student.playlists;

import snhu.jukebox.playlist.PlayableSong;
import snhu.jukebox.playlist.Song;
import music.artist.*;
import java.util.ArrayList;
import java.util.LinkedList;

public class DominickMarquez_Playlist {
	public LinkedList<PlayableSong> StudentPlaylist(){
		
	LinkedList<PlayableSong> playlist = new LinkedList<PlayableSong>();
	
	// Metallica
	ArrayList<Song> metallicaTracks = new ArrayList<Song>();
	Metallica theMetallicaBand = new Metallica();
	
	metallicaTracks = theMetallicaBand.getMetallicaSongs();
	
	playlist.add(metallicaTracks.get(0));
	playlist.add(metallicaTracks.get(1));
	
	// Sleeping With Sirens
	ArrayList<Song> sleepingWithSirensTracks = new ArrayList<Song>();
	SleepingWithSirens theSleepingWithSirensBand = new SleepingWithSirens();
	
	sleepingWithSirensTracks = theSleepingWithSirensBand.getSleepingWithSirensSongs();
	
	playlist.add(sleepingWithSirensTracks.get(0));
	playlist.add(sleepingWithSirensTracks.get(1));
	
	// Stray Kids
	ArrayList<Song> StrayKids = new ArrayList<Song>();
	StrayKids theStrayKidsBand = new StrayKids();
	
	StrayKidsTracks = theStrayKidsBand.getStrayKidsSongs();
	
	playlist.add(StrayKidsTracks.get(0));
	
	return playlist;
	}
}
